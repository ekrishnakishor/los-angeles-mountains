# LosAngeles_Mountains

## This is a Demo HTML CSS website made for educational use

![los-angeles](https://user-images.githubusercontent.com/91717723/137840185-cd51eeb8-017f-4cc9-8d3f-142174133b78.png)

> Languages Used
- HTML
- CSS
- PHP

# [Live Website Link](https://losangelesmountains.herokuapp.com/)

> You can resuse it to get yourslef familiarize with display properties in CSS
